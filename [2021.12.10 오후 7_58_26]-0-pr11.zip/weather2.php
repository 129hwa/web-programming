<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>수도권 날씨예보</title>
    <style>
    </style>
</head>
<body>
    

    <form name="cast" method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
        <h3>수도권 날씨예보</h3>
        <select name="weather_cast" onclick="change(this);">
            <option name="region" value="과천" >과천</option>
            <option name="region" value="서울">서울</option>
            <option name="region" value="성남">성남</option>
            <option name="region" value="수원">수원</option>
            <option name="region" value="용인">용인</option>
            <option name="region" value="인천">인천</option>
        </select>
        의 날씨는?
    <br>
    
    <script tyep="text/javascript">

        var select = document.getElementById('weather_cast').options[document.getElementById('weather_cast').selectedIndex].;


        function change(weather_cast)
        {
            var selec = weather_cast[weather_cast.selectedIndex].value;
        }
    </script>
    <?php
        
        echo "<div id='show_cast'>";

        $region = $_POST["weather_cast"];
        
        echo "<h3>{$region}의 날씨</h3>";
    
        $con = mysqli_connect("localhost", "user1", "12345", "sample");

        $sql = "select * from weather where city='$region'";

        $result = mysqli_query($con, $sql);
        while($row = mysqli_fetch_array($result))
        {
            echo "최고 기온 ".$row['high_temp']."도<br>";
            echo "최저 기온 ".$row['low_temp']."도<br>";
            echo "비올 확률 ".$row['rain_ratio']."%<br>";
            echo "예상 강수량 ".$row['rain_mm']."mm";
        }

        mysqli_close($con);

        echo "</div>";
    ?>

    </form>
</body>
</html>