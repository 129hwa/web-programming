<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>수도권 날씨예보</title>
</head>
<body>
    <form name="weather" method="POST" action="get_weather.php">
        <h3>수도권 날씨예보</h3>
        <select name="loc">
            <option name="" value="과천">과천</option>
            <option name="" value="서울">서울</option>
            <option name="" value="성남">성남</option>
            <option name="" value="수원">수원</option>
            <option name="" value="용인">용인</option>
            <option name="" value="인천">인천</option>
        </select>
        의 날씨는?
        <input type="submit" value="선택">
</body>
</html>