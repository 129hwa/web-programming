<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>수도권 날씨예보</title>
</head>
<body>
    <?php
        $loc = $_POST["loc"];
        
        echo "<h3>{$loc}의 날씨</h3>";
    
        $con = mysqli_connect("localhost", "user1", "12345", "sample");

        $sql = "select * from weather where city='$loc'";

        $result = mysqli_query($con, $sql);
        while($row = mysqli_fetch_array($result))
        {
            echo "최고 기온 ".$row['high_temp']."도<br>";
            echo "최저 기온 ".$row['low_temp']."도<br>";
            echo "비올 확률 ".$row['rain_ratio']."%<br>";
            echo "예상 강수량 ".$row['rain_mm']."mm";
        }
        
        //if(myssqli_connect_errno())
        //    echo "DB 연결에 실패했습니다.".mysqli_connect_error();

        //$num_record = mysqli_num_rows($result);

        //echo "$result";

        mysqli_close($con);

        
    ?>
</body>
</html>